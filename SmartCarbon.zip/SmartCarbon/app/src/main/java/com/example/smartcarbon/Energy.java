package com.example.smartcarbon;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

//Energy class, a series of pictures that implement the scroll function demonstrated in the linked XML File
public class Energy extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_energy);
    }
}
